#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include "state_facts.h"

using namespace std;

int main(int argc, char** argv){
	ifstream file;
	char *filename = new char[256];
	cout << filename << endl;
	int num_states = 0, num_counties = 0, input = 0;
	bool valid_arguments = is_valid_arguments(argv, argc);
	num_states = get_states(argv, argc, input);
	for(int i=0; i<argc; i++){
		if(strcmp(argv[i], "-f") == 0){
			filename = argv[i+1];
		}
	}
	file.open(filename);
	if(file.fail()){
		cout << "You have entered an invalid file\nPlease use states1.txt" << endl;		
		cin.getline(filename, 256);
		file.open(filename);
		state *states = create_states(num_states);
		get_state_data(states, num_states, file);
		print_info(states, num_states);
		delete_info(&states, num_states);
	}
	state *states = create_states(num_states);
	get_state_data(states, num_states, file);
	print_info(states, num_states);
	delete_info(&states, num_states);
	free(filename);
	delete [] filename;
	file.close();			
	return 0;
}
