#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include "state_facts.h"

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: is_valid_arguments
** Description: This function will determine if the arguments are valid or not
** Parameters: char **, int
** Input: Command line arguments
** Output: boolean
****************************************************************************************************************************************************************************************/
bool is_valid_arguments(char **argv, int argc){
	bool check = true;
	if(argc < 5){
		check = false;
		cout << "You have entred an invalid number of arguments\nPlease try again" << endl;
		exit(0);
	}
	if(strcmp(argv[1], "-s") != 0){
		if(strcmp(argv[3], "-s") != 0){
			check = false;
			cout << "You have entered invalid arguments\nPlease try again using -f and -s" << endl;
			exit(0);
		}
	}
	if(strcmp(argv[1], "-f") != 0){
		if(strcmp(argv[3], "-f") != 0){
			check = false;
			cout << "You have entered invalid arguments\nPlease try again using -f and -s" << endl;
			exit(0);
		}
	}
	return check;
}

/****************************************************************************************************************************************************************************************
** Function: get_states
** Description: This function will get the number of states from the command line argument
** Parameters: char **, int, int
** Input: Command Line argument
** Output: int
****************************************************************************************************************************************************************************************/
int get_states(char **argv, int argc, int input){
	for(int i=0; i<argc; i++){
		if(strcmp(argv[i], "-s") == 0)
			input = atoi(argv[i+1]);
	}
	while(input < 1){
		cout << "Please enter a nonzero integer for the number of states" << endl;
		cin >> input;
	}
	return input;
}

/****************************************************************************************************************************************************************************************
** Function: get_file
** Description: This function will get the file from a user if bad input is received
** Parameters: char **, int, int 
** Input: Command line arguments
** Output: string
****************************************************************************************************************************************************************************************/
char* get_file(char ** argv, int argc, char* input, ifstream &){
	fstream file;
	for(int i=0; i<argc; i++){
		if(strcmp(argv[i], "-f") == 0){
			input = argv[i+1];
			cout << input << endl;
		}
	}
	file.open(input);
	if(file.fail()){
		do{
			cout << "You have entered an invalid file\nPlease use states1.txt" << endl;
			cin.getline(input, 256);
			cout << input << endl;
		}
		while(input != "states1.txt");
	}
}
	
/****************************************************************************************************************************************************************************************
** Function: create_states
** Description: This function will generate an array of states 
** Parameters: int
** Input: int
** Output: struct
****************************************************************************************************************************************************************************************/
state *create_states(int num_states){
	state *states = new state[num_states];
	return states;
}

/****************************************************************************************************************************************************************************************
** Function: get_state_data
** Description: This function will read the file and get the information on each state
** Parameters: struct, int, fstream
** Input: struct, int, fstream
** Output: void
****************************************************************************************************************************************************************************************/
void get_state_data(state *states, int num_states, ifstream &file){
	int num_counties = 0;
	ofstream info;
	for(int i=0; i<num_states; i++){
		file >> states[i].name;
		file >> states[i].population;
		file >> states[i].counties;
		states[i].c = create_counties(states[i].counties);
		get_county_data(states[i].c, states[i].counties, file);
		/*num_counties = states[i].counties;
		states[i].c = new county[num_counties];
		for(int j=0; j<num_counties; j++){
			file >> states[i].c[j].name;
			file >> states[i].c[j].population;
			file >> states[i].c[j].avg_income;
			file >> states[i].c[j].avg_house;
			file >> states[i].c[j].cities;
			int num_cities = states[i].c[j].cities;
			for(int k=0; k<num_cities; k++){
				file >> states[i].c[j].city[k];
			}
		}*/
	}
}
/****************************************************************************************************************************************************************************************
** Function: create_counties
** Description: This function will create an array for the number of counties 
** Parameters: int
** Input: int
** Output: struct
****************************************************************************************************************************************************************************************/
county *create_counties(int num_counties){
	county *counties = new county[num_counties];
	return counties;
}

/****************************************************************************************************************************************************************************************
** Function: get_county_data
** Description: This function will retreive the county information from the file
** Parameters: struct, int, fstream
** Input: struct, int, fstream
** Output: Void
****************************************************************************************************************************************************************************************/
void get_county_data(county *c, int num_counties, ifstream &file){
	int num_city = 0;
	for(int j=0; j<num_counties; j++){
		file >> c[j].name;
		file >> c[j].population;
		file >> c[j].avg_income;
		file >> c[j].avg_house;
		file >> c[j].cities;
		num_city = c[j].cities;
		c[j].city = new string[num_city];
		for(int k=0; k<num_city; k++){
			file >> c[j].city[k];
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: delete_info
** Description: This function will delete the memory allocated on the heap
** Parameters: char **, int
****************************************************************************************************************************************************************************************/
void delete_info(state **states, int num_states){
	for(int i=0; i<num_states; i++){
		for(int j=0; j < (*states)[i].counties; j++){
			delete []( *states)[i].c[j].city;
		}
		delete [] (*states[i]).c;
	}
	delete [] (*states);
	states = NULL;
}

/****************************************************************************************************************************************************************************************
** Function: max_pop
** Description: This function will loop through the state and county structs and determine the largest population from each
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void max_pop(state *states, int num_states){
	/*for(int i=0; i<num_states; i++){
		if(states[i].population > states[i+1].population)
	}*/		
	int scomp = 0, ccomp = 0, sline = 0, cline = 0, spos = 0, cpos = 0;
	scomp = states[0].population;
	ccomp = states[0].c[0].population;
	for(int i=0; i<num_states; i++){
		if(states[i].population > scomp){
			scomp = states[i].population;
			spos = i;
		}
		for(int j=0; j<states[i].counties; j++){
			if(states[i].c[j].population > ccomp){
				ccomp = states[i].c[j].population;
				cpos = j; spos = i;
			}
		}
	}
	cout << "The state with the largest population is: " << states[spos].name << endl;
	cout << "The county with the largest population is: " << states[spos].c[cpos].name << endl;
	//cout << "The largest state population is: " << smax << endl;
	//cout << "The largest county population is: " << cmax << endl;
}

/****************************************************************************************************************************************************************************************
** Function: county_income
** Description: This function will take input from the user regarding income and return the counties with an income above that set amount
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void county_income(state *states, int num_states){
	int input = 0;
	cout << "Please enter a number to find the counties with an income above a specific amount" << endl;
	cin >> input;
	cout << "Counties with an income above: " << input << endl;
	for(int i=0; i<num_states; i++){
		for(int j=0; j<states[i].counties; j++){
			if(states[i].c[j].avg_income >= input)
				cout << states[i].c[j].name << endl;
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: avg_house
** Description: This function will determine the average household cost for the counties in each state
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void avg_house(state *states, int num_states){
	int house_avg = 0;
	cout << "Average house cost for every county in the state" << endl;
	for(int i=0; i<num_states; i++){
		cout << states[i].name << ": " << endl;
		for(int j=0; j<states[i].counties; j++){
			house_avg += states[i].c[j].avg_house;
		}
		house_avg = (house_avg)/(states[i].counties);
		cout << house_avg << endl;
	}
}
			
/****************************************************************************************************************************************************************************************
** Function: states_by_pop
** Description: This function will show the user the states in order of population size
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void states_by_pop(state *states, int num_states){
	cout << "States in order by population size: " << endl;
	for(int i=0; i<num_states; i++){
		if(states[i].population > states[i+1].population)
			cout << states[i].name << endl;
		else if(states[i].population < states[i+1].population)
			cout << states[i+1].name << endl;
		else
			cout << states[i].name << endl;
	}
}

/****************************************************************************************************************************************************************************************
** Function: counties_by_pop
** Description: This function will sort the counties in order of population
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void counties_by_pop(state *states, int num_states){
	cout << "Counties in order by population size: " << endl;
	for(int i=0; i<num_states; i++){
		for(int j=0; j<states[i].counties; j++){
			if(states[i].c[j].population > states[i].c[j+1].population)
				cout << states[i].c[j].name << endl;
			else if(states[i].c[j].population < states[i].c[j+1].population)
				cout << states[i].c[j+1].name << endl;
			else 
				cout << states[i].c[j].name << endl;
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: states_by_name
** Description: This function will sort the states in order by name
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void states_by_name(state *states, int num_states){
	state state_temp;
	cout << "States sorted in alphabetical order: " << endl;
	for(int i=0; i<num_states; i++){
		for(int j=1; j<num_states; j++){
			if(states[j].name[0] < states[i].name[0]){
				state_temp = states[i];
				states[i] = states[j];
				states[j] = state_temp;
			}
		}	
	cout << states[i].name << endl;
	/*county county_temp;
	if(states[i].counties >1){
		for(int j=0; j<states[i].counties; j++){
			for(int k=1; k<states[i].counties; k++){
				if(states[i].c[k].name[0] < states[i].c[j].name[0]){
					county_temp = states[i].c[j];
					states[i].c[j] = states[i].c[k];
					states[i].c[k] = county_temp;
				}
			}
			cout << states[i].c[j].name << endl;
		}
	}
	else{
		cout << states[i].c[0].name << endl;
		}
	}*/
	}
}
/****************************************************************************************************************************************************************************************
** Function: counties_by_name
** Description: This function will sort the counties by name
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void counties_by_name(state *states, int num_states){
	//state states;
	county county_temp;
	cout << "Counties sorted in alphabetical order: " << endl;
	for(int i=0; i<num_states; i++){
		if(states[i].counties > 1){
		for(int j=0; j<states[i].counties; j++){
			for(int k=1; k<states[i].counties; k++){
				if(states[i].c[k].name[0] < states[i].c[j].name[0])
					county_temp = states[i].c[j];
					states[i].c[j] = states[i].c[k];
					states[i].c[k] = county_temp;
				}	
			cout << states[i].c[j].name << endl;
		}
		}
		else{
			cout << states[i].c[0].name << endl;
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: print_info
** Description: This function will take user input and determine how to print the information from the user
** Parameters: struct, int
** Input: struct, int
** Output: void
****************************************************************************************************************************************************************************************/
void print_info(state *states, int num_states){
	cout << "How would you like the information to be printed?\nIf you would like to print straight to the screen, enter 1\nIf you would like to print to a file, enter 2" << endl;
	int input = 0;
	cin >> input;
	if(input == 1){
		max_pop(states, num_states);
		county_income(states, num_states);
		avg_house(states, num_states);
		states_by_name(states, num_states);
		states_by_pop(states, num_states);
		counties_by_pop(states, num_states);
		counties_by_name(states, num_states);
	}
	else if(input == 2){
		ofstream output;
		cout << "Please enter the name of the file you wish to have the informtion stored in" << endl;
		char *file = new char[256];
		cin.getline(file, 256);
		output.open(file);

	}

}
