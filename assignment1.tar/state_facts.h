#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;

struct county{
	string name;
	int population;
	float avg_income;
	float avg_house;
	int cities;
	string *city;
};

struct state{
	string name;
	int population;
	int counties;
	struct county *c;
};

bool is_valid_arguments(char **, int);
state *create_states(int);
void get_state_data(state *, int, ifstream &);
county *create_counties(int);
void get_county_data(county *, int, ifstream &);
void delete_info(state **, int);
void print_info(state*, int);
void max_pop(state *, int);
void county_income(state *, int);
void avg_house(state *, int);
void states_by_name(state *, int);
void states_by_pop(state *, int);
void counties_by_name(state *, int);
void counties_by_pop(state *, int);
int get_states(char **, int, int);
char* get_file(char **, int, char*, ifstream &); 
