#ifndef TENANT_H
#define TENANT_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
 
using namespace std;

class Tenant {

	private:

	protected:
		
		int agreeability;
		float budget;

	public:

		Tenant();
		Tenant(const Tenant &);
		const Tenant &operator=(const Tenant &);
		~Tenant();

};

#endif 
