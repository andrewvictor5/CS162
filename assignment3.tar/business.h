#ifndef BUSINESS_H
#define BUSINESS_H
#include "property.h"

using namespace std;

struct space{
	string size;
};

class Business:public Property{

	private:
		int spaces;
		struct space *s;
		float rent;
		int num_businesses;
		class Businesses *b;
	public:
		Business();
		//Business(float, string, float, float, int);
		Business(const Business &);
		const Business &operator=(const Business &);
		~Business();
		float get_property_value() const;
		void set_property_value(float);
		float generate_pv();
		string get_location() const;
		void set_location();
		float get_mortgage() const;
		void set_mortgage();
		float get_property_tax() const;
		int get_spaces() const;
		void set_spaces();
		struct space* get_sizes();
		float get_rent() const;
		void set_rent(float);
		float generate_rent();
		int get_businesses();
		void set_businesses(int);

};

#endif 
