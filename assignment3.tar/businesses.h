#ifndef BUSINESSES_H
#define BUSINESSES_H
#include "tenant.h"

using namespace std;

class Businesses:public Tenant{

	private:

	public:
		Businesses();
		Businesses(const Businesses &);
		const Businesses &operator=(const Businesses &);
		~Businesses();
		int get_agreeability() const;
		void set_agreeability();
		float get_budget() const;
		void set_budget();

};

#endif
