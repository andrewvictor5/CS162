#ifndef HOUSE_H
#define HOUSE_H
#include "property.h"
#include "citizen.h"

using namespace std;

class House:public Property{

	private:
		float rent;
		int num_citizens;
		class Citizen *c;
	public:
		House();
		//House(float, string, float, float, int);
		House(const House &);
		const House &operator=(const House &);
		~House();
		float get_property_value() const;
		void set_property_value(float);
		float generate_pv();
		string get_location() const;
		void set_location();
		float get_mortgage() const;
		void set_mortgage();
		float get_property_tax() const;
		int get_tenants() const;
		void set_tenants(int);
		float get_rent() const;
		void set_rent(float);
		float generate_rent();
		int get_citizens() const;
		void set_citizens(int); 

};

#endif
