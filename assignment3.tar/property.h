#ifndef PROPERTY_H
#define PROPERTY_H
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Property {
	
	private:
	
	protected: 
		
		float property_value;
		string location;
		float mortgage;
		float property_tax;
		int tenants;

	public:
		
		Property();
		//Property(float, string, float, float, int);
		float get_property_value() const;
		void set_property_value(float);
		string get_location() const;
		void set_location(string);
		float get_mortgage() const;
		void set_mortgage(float);
		float get_tax() const;
		void set_tax(float);
		int get_tenants() const;
		void set_tenants(int);
		Property(const Property &);
		const Property &operator=(const Property &);
		~Property();
};
#endif
