#include <iostream>
#include <string>
#include <fstream>
#include "property.h"
#include "house.h"
#include "apartment.h"
#include "business.h"
#include "tenant.h"
#include "citizen.h"
#include "businesses.h"
#include "game.h"

using namespace std;

int main(){
	srand(time(NULL));
	Property p;
	Game g;
	g.run_game();
	return 0;
}
