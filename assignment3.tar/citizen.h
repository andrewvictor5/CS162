#ifndef CITIZEN_H
#define CITIZEN_H
#include "tenant.h"

using namespace std;

class Citizen:public Tenant{

	private:

	public:
		Citizen();
		Citizen(const Citizen &);
		const Citizen &operator=(const Citizen &);
		~Citizen();
		int get_agreeability() const;
		void set_agreeability();
		float get_budget() const;
		void set_budget();

};

#endif
