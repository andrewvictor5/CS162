#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <string>
#include <cstdlib>
#include "property.h"
#include "tenant.h"
#include "house.h"
#include "apartment.h"
#include "business.h"
#include "citizen.h"
#include "businesses.h"

using namespace std;

class Game {
	private:
		int bank;
		House *active_h;
		Apartment *active_a;
		Business *active_b;
		House *h_owned;
		Apartment *a_owned;
		Business *b_owned;
		int num_h_owned;
		int num_a_owned;
		int num_b_owned;
	public:
		
		Game();
		~Game();
		int get_bank() const;
		void set_bank();
		void set_properties();
		void run_game();
		int property_details();
		int buy_property();
		void buy_house(int);
		void buy_apartment(int);
		void buy_business(int);
		void take_turn(int);
		void collect_rent();
		void collect_rent_h();
		void collect_rent_a();
		void collect_rent_b();
		void collect_mortgage();
		void collect_mortgage_h();
		void collect_mortgage_a();
		void collect_mortgage_b();
		void change_rent();
		void change_rent_h();
		void change_rent_a();
		void change_rent_b();
		void get_tax();
		void get_tax_h();
		void get_tax_a();
		void get_tax_b();
		void random_event();
		void random_event_h();
		void random_event_a();
		void random_event_b();
		bool can_sell();
		bool can_sell_h();
		bool can_sell_a();
		bool can_sell_b();
		void sell_property(); 
		void sell_house();
		void sell_apartment();
		void sell_business();
		House *get_active_h() const;
		House *set_active_h(House *);
		Business *get_active_b() const;
		Business *set_active_b(Business *);
		Apartment *get_active_a() const;
		Apartment *set_active_a(Apartment *);
		int get_num_h_owned() const;
		void set_num_h_owned(int);
		int get_num_a_owned() const;
		void set_num_a_owned(int);
		int get_num_b_owned() const;
		void set_num_b_owned(int);

};
#endif
