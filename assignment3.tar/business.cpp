#include "business.h"
#include "property.h"

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: Business
** Description: Constructor
** Parameters: N/A
** Input: N/A
** Output: Initialized Class
****************************************************************************************************************************************************************************************/

Business::Business():Property() {
	set_property_value(generate_pv());
	set_location();
	set_mortgage();
	set_spaces();
	set_rent(generate_rent());
	num_businesses = get_spaces();
	Businesses *b;
	set_businesses(num_businesses);
	//b = new Businesses[get_spaces()];
}

/****************************************************************************************************************************************************************************************
** Function: Business
** Description: Copy Constructor
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

Business::Business(const Business &copy):Property(copy){
	property_value = copy.property_value;
	location = copy.location;
	mortgage = copy.mortgage;
	property_tax = copy.property_tax;
	spaces = copy.spaces;
	rent = copy.rent;
	num_businesses = copy.num_businesses;
}

/****************************************************************************************************************************************************************************************
** Function: Business
** Description: Assignment Operator Overload
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/
const Business &Business::operator=(const Business & copy){
	Property::operator = (copy);
	property_value = copy.property_value;
	location = copy.location;
	mortgage = copy.mortgage;
	property_tax = copy.property_tax;
	spaces = copy.spaces;
	rent = copy.rent;
	num_businesses = copy.num_businesses;

	return *this;
}
/****************************************************************************************************************************************************************************************
** Function: Business
** Description: Destructor
** Parameters: N/A
** Input: N/A
** Output: Frees dynamic memory
****************************************************************************************************************************************************************************************/

Business::~Business(){
	delete[] s;
	//delete[] b;
}

/****************************************************************************************************************************************************************************************
** Function: get_property_value
** Description: This function will get the property value for the business complex
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

float Business::get_property_value() const {return property_value;}

/****************************************************************************************************************************************************************************************
** Function: get_property_value
** Description: This function will get the property value for the business complex
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

void Business::set_property_value(float pv){
	property_value = pv;
}

/****************************************************************************************************************************************************************************************
** Function: set_property_value
** Description: This function will set the property value for each business complex
** Parameters: float
** Input: float
** Output: float
****************************************************************************************************************************************************************************************/

float Business::generate_pv(){
	property_value = rand() % 200001 + 400000;
	property_tax = 0.015 * property_value;
	return property_value;
}

/****************************************************************************************************************************************************************************************
** Function: get_location
** Description: This function will get the location for each business complex
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

string Business::get_location() const {return location;}

/****************************************************************************************************************************************************************************************
** Function: set_location
** Description: This function will set the location for each business complex
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

void Business::set_location(){
	int num;
	num = rand() % 5 + 1;
	switch(num){
		case 1: location = "SE"; break;
		case 2: location = "NE"; break;
		case 3: location = "Midwest"; break;
		case 4: location = "SW"; break;
		case 5: location = "NW"; break;
		default: location = " ";
	}
}

/****************************************************************************************************************************************************************************************
** Function: get_mortgage
** Description: This function will get the mortgage for the business complex
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

float Business::get_mortgage() const {return mortgage;}

/****************************************************************************************************************************************************************************************
** Function: set_mortgage
** Description: This function will set the mortgage for each business complex
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

void Business::set_mortgage(){
	mortgage = rand() % 5001 + 1;
}

/****************************************************************************************************************************************************************************************
** Function: get_property_tax
** Description: This function will get the property tax for each business complex
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

float Business::get_property_tax() const {return property_tax;}

/****************************************************************************************************************************************************************************************
** Function: get_spaces
** Description: This function will get the number of spaces in the business complex
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Business::get_spaces() const {return spaces;}

/****************************************************************************************************************************************************************************************
** Function: set_spaces
** Description: This function will set the number of spaces in each business complex
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

void Business::set_spaces(){
	spaces = rand() % 5 + 1;
	s = new space[spaces];
	int num;
	for(int i=0; i<spaces; i++){
		num = rand() % 3 + 1;
		switch(num) {
			default: s[i].size = " ";
			break;
			case 1: s[i].size = "Small";
			break;
			case 2: s[i].size = "Medium";
			break;
			case 3: s[i].size = "Large";
			break;
		}
	}
	/*for(int i=0; i<spaces; i++){
		cout << s[i].size << endl;
	}*/
}

/****************************************************************************************************************************************************************************************
** Function: get_spaces
** Description: This function will get the different sized spaces for the space struct
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

struct space* get_sizes(){
	
}

/****************************************************************************************************************************************************************************************
** Function: get_rent
** Description: This function will get the rent for each space in the business
** Parameters: N/A
** Input: N/A
** Output: float
****************************************************************************************************************************************************************************************/

float Business::get_rent() const {return rent;}

/****************************************************************************************************************************************************************************************
** Function: set_rent
** Description: This function will set the rent for each space in the business
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

void Business::set_rent(float r) {
	rent = r;
}

/****************************************************************************************************************************************************************************************
** Function: set_rent
** Description: This function will set the rent for each space in the business
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

float Business::generate_rent(){
	float r = rand() % 1001+1000;
	return r;
}

/****************************************************************************************************************************************************************************************
** Function: get_businesses
** Description: This function will get the businesses for each space in the business
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Business::get_businesses() {return num_businesses;}

/****************************************************************************************************************************************************************************************
** Function: set_businesses
** Description: This function will set the rent for each space in the business
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

void Business::set_businesses(int num){
	num = num_businesses;
}
