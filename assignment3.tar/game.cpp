#include "game.h"

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: Game
** Description: This function will set up the game class for the player
** Parameters: N/A
** Input: N/A
** Output: Initialized class
****************************************************************************************************************************************************************************************/

Game::Game() {
	set_bank();
	active_h = new House[3];
	active_a = new Apartment[3];
	active_b = new Business[3];
	h_owned = NULL;
	a_owned = NULL;
	b_owned = NULL;
	num_h_owned = 0;
	num_a_owned = 0;
	num_b_owned = 0;
}

/****************************************************************************************************************************************************************************************
** Function: Game
** Description: Destructor
** Parameters: N/A
** Input: N/A
** Output: Freed dynamic memory
****************************************************************************************************************************************************************************************/

Game::~Game() {
	delete [] active_h;
	delete [] active_a;
	delete [] active_b;
	delete [] h_owned;
	delete [] a_owned;
	delete [] b_owned;
}

/****************************************************************************************************************************************************************************************
** Function: get_bank
** Description: This function will get the bank value for the player
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Game::get_bank() const {return bank;}

/****************************************************************************************************************************************************************************************
** Function: set_bank
** Description: This function will set the bank value for the player
** Parameters: 
** Input:
** Output:
****************************************************************************************************************************************************************************************/

void Game::set_bank() {
	bank = 500000;
}

/****************************************************************************************************************************************************************************************
** Function: get_active_h
** Description: This function will get the number of active houses 
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

House *Game::get_active_h() const {return active_h;}

/****************************************************************************************************************************************************************************************
** Function: set_active_h
** Description: This function will set the number of active houses 
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

House *Game::set_active_h(House *h) {active_h = h;}

/****************************************************************************************************************************************************************************************
** Function: get_active_a
** Description: This function will get the number of active apartments
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

Apartment *Game::get_active_a() const {return active_a;}

/****************************************************************************************************************************************************************************************
** Function: set_active_a
** Description: This function will set the number of active apartments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

Apartment *Game::set_active_a(Apartment *a) {active_a = a;}

/****************************************************************************************************************************************************************************************
** Function: get_active_b
** Description: This function will get the number of active businesses 
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

Business *Game::get_active_b() const {return active_b;}

/****************************************************************************************************************************************************************************************
** Function: set_active_b
** Description: This function will set the number of active businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

Business *Game::set_active_b(Business *b) {active_b = b;}

/****************************************************************************************************************************************************************************************
** Function: get_num_h_owned
** Description: This function will get the number of houses owned
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Game::get_num_h_owned() const {return num_h_owned;}

/****************************************************************************************************************************************************************************************
** Function: set_num_h_owned
** Description: This function will set up the number of houses owned
** Parameters: int
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::set_num_h_owned(int h) {num_h_owned = h;}

/****************************************************************************************************************************************************************************************
** Function: get_num_a_owned
** Description: This function will get the number of apartments owned
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Game::get_num_a_owned() const {return num_a_owned;}

/****************************************************************************************************************************************************************************************
** Function: set_num_a_owned
** Description: This function will set up the number of apartments owned
** Parameters: int
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::set_num_a_owned(int a) {num_a_owned = a;}

/****************************************************************************************************************************************************************************************
** Function: get_num_b_owned
** Description: This function will get the number of businesses owned
** Parameters: N/A
** Input: N/A
** Output: int
****************************************************************************************************************************************************************************************/

int Game::get_num_b_owned() const {return num_b_owned;}

/****************************************************************************************************************************************************************************************
** Function: set_num_b_owned
** Description: This function will set up the number of businesses owned
** Parameters: int
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::set_num_b_owned(int b) {num_b_owned = b;}

/****************************************************************************************************************************************************************************************
** Function: property_details
** Description: This function will show the random values generated for each property
** Parameters: N/A
** Input: N/A
** Output: Details about the properties
****************************************************************************************************************************************************************************************/

int Game::property_details() {
	int num = rand() % 3;
	cout << "House\nProperty Value: " << active_h[num].get_property_value() << endl;
	cout << "Property Tax: " << active_h[num].get_property_tax() << endl;
	cout << "Mortgage: " << active_h[num].get_mortgage() << endl;
	cout << "Location: " << active_h[num].get_location() << "\n" << endl;
	cout << "Apartment Complex\nProperty Value: " << active_a[num].get_property_value() << endl;
	cout << "Property Tax: " << active_a[num].get_property_tax() << endl;
	cout << "Mortgage: " << active_a[num].get_mortgage() << endl;
	cout << "Location: " << active_a[num].get_location() << "\n" << endl;
	cout << "Business Complex\nProperty Value: " << active_b[num].get_property_value() << endl;
	cout << "Property Tax: " << active_b[num].get_property_tax() << endl;
	cout << "Mortgage: " << active_b[num].get_mortgage() << endl;
	cout << "Location: " << active_b[num].get_location() << "\n" << endl;
	
	return num;
}

/****************************************************************************************************************************************************************************************
** Function: buy_property
** Description: This function will set up the 3 random properties at the beginning of the game
** Parameters: N/A
** Input: N/A
** Output: 3 Random Properties
****************************************************************************************************************************************************************************************/

int Game::buy_property() {
	int i = property_details();
	cout << "To buy a house, enter 1\nTo buy an apartment complex, enter 2\nTo buy a business complex, enter 3\n" << endl;
	int num = rand() % 3;
	int input;
	cin >> input;
	if(input == 1){
		buy_house(num);
		cout << "Congratulations, you have bought a house\n" << endl;
	}
	if(input == 2){
		buy_apartment(num);
		cout << "Congratulations, you have bought an apartment complex\n" << endl;
	}
	if(input == 3){
		buy_business(num);
		cout << "Congratulations, you have bought a business complex\n" << endl;
	}
	return num;
}

/****************************************************************************************************************************************************************************************
** Function: buy_house
** Description: This function will allow the user to buy a house
** Parameters: N/A
** Input: N/A
** Output: House
****************************************************************************************************************************************************************************************/

void Game::buy_house(int num) {
	if(num_h_owned > 0){
		House *temporary_h = new House[num_h_owned+1];
		for(int i = 0; i < num_h_owned; i++) {
			temporary_h[i] = h_owned[i];
		}
		delete [] h_owned;
		temporary_h[num_h_owned-1] = h_owned[num];
		num_h_owned += 1;	
		h_owned = temporary_h;
		temporary_h = NULL;
	}
	else if(num_h_owned == 0){
		h_owned = new House[1];
		h_owned[0] = active_h[num];
		num_h_owned += 1;
	}
}

/****************************************************************************************************************************************************************************************
** Function: buy_apartment
** Description: This function will allow the user to buy an apartment complex
** Parameters: N/A
** Input: N/A
** Output: Apartment Complex
****************************************************************************************************************************************************************************************/

void Game::buy_apartment(int num) {
	if(num_a_owned > 0){
		Apartment *temporary_a = new Apartment[num_a_owned+1];
		for(int i=0; i<num_a_owned; i++){
			temporary_a[i] = a_owned[i];
		}
		delete [] a_owned;
		temporary_a[num_a_owned-1] = a_owned[num];
		num_a_owned += 1;
		a_owned = temporary_a;
		temporary_a = NULL;
	}
	else if(num_a_owned == 0){
		a_owned = new Apartment[1];
		a_owned[0] = active_a[num];
		num_a_owned += 1;
	}
}

/****************************************************************************************************************************************************************************************
** Function: buy_business
** Description: This function will allow the user to buy a business complex
** Parameters: N/A
** Input: N/A
** Output: Business Complex
****************************************************************************************************************************************************************************************/

void Game::buy_business(int num) {
	if(num_b_owned > 0){
		Business *temporary_b = new Business[num_b_owned+1];
		for(int i=0; i<num_b_owned; i++){
			temporary_b[i] = b_owned[i];
		}
		delete [] b_owned;
		temporary_b[num_b_owned-1] = b_owned[num];
		num_b_owned += 1;
		b_owned = temporary_b;
		temporary_b = NULL;
	}
	else if(num_b_owned == 0){
		b_owned = new Business[1];
		b_owned[0] = active_b[num];
		num_b_owned += 1;
	}

}

/****************************************************************************************************************************************************************************************
** Function: collect_rent
** Description: This function will collect rent
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_rent() {
	collect_rent_h();
	collect_rent_a();
	collect_rent_b();
	cout << "Bank Account after collecting rent: \n" << get_bank() << endl;
}

/****************************************************************************************************************************************************************************************
** Function: collect_rent_h
** Description: This function will collect rent for the houses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_rent_h() {
	for(int i=0; i<num_h_owned; i++){
		bank += h_owned[i].get_rent();
	}
}

/****************************************************************************************************************************************************************************************
** Function: collect_rent_a
** Description: This function will collect rent for the apatments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_rent_a() {
	for(int i=0; i<num_a_owned; i++){
		for(int j=0; j<a_owned[i].get_rooms(); j++){
			bank += a_owned[j].get_rent();
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: collect_rent_b
** Description: This function will collect rent for the businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_rent_b() {
	for(int i=0; i<num_b_owned; i++){
		for(int j=0; j<b_owned[i].get_spaces(); j++){
			bank += b_owned[j].get_rent();
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function: collect_rent
** Description: This function will collect rent
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_mortgage() {
	collect_mortgage_h();
	collect_mortgage_a();
	collect_mortgage_b();
	cout << "Bank Account after paying mortgage: \n" << get_bank() << endl;
}

/****************************************************************************************************************************************************************************************
** Function: collect_mortgage_h
** Description: This function will collect mortgage for the houses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_mortgage_h() {
	for(int i=0; i<num_h_owned; i++){
		bank -= h_owned[i].get_mortgage();
	}
}

/****************************************************************************************************************************************************************************************
** Function: collect_mortgage_a
** Description: This function will collect mortgage for the apatments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_mortgage_a() {
	for(int i=0; i<num_a_owned; i++){
		bank -= a_owned[i].get_mortgage();
	}
}

/****************************************************************************************************************************************************************************************
** Function: collect_mortgage_b
** Description: This function will collect mortgage for the businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::collect_mortgage_b() {
	for(int i=0; i<num_b_owned; i++){
		bank -= b_owned[i].get_mortgage();
	}
}

/****************************************************************************************************************************************************************************************
** Function: random_event
** Description: This function will simulate a random event
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::random_event() {
	random_event_h();
	random_event_a();
	random_event_b();
}

/****************************************************************************************************************************************************************************************
** Function: random_event_h
** Description: This function will simulate a random event for houses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::random_event_h() {
	int num = rand() % 6 + 1;
	//for(int i=0; i<num_h_owned; i++){
		if(num == 1){
			for(int i=0; i<num_h_owned; i++){
				if(active_h[i].get_location() == "SE"){
					cout << "A Hurricane occurred, all property values located in the SE are decreased by 50%\n" << endl;
					float pv = active_h[i].get_property_value() * 0.5;
					active_h[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_h[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 2){
			for(int i=0; i<num_h_owned; i++){
				if(active_h[i].get_location() == "Midwest"){
					cout << "A torando occurred, all property values located in the Midwest have decreased by 30%\n" << endl;
					float pv = active_h[i].get_property_value() * 0.7;
					active_h[i].set_property_value(pv);
					cout << "New Property Valie: \n" << active_h[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 3){
			for(int i=0; i<num_h_owned; i++){
				if(active_h[i].get_location() == "NW"){
					cout << "An earthquake occurred, all property values in the NW have decreased by 90%\n" << endl;
					float pv = active_h[i].get_property_value() * 0.1;
					active_h[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_h[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 4){
			for(int i=0; i<num_h_owned; i++){
				if(active_h[i].get_location() == "SW"){
					cout << "A wildfire occurred, all property values in the SW have decreased by 25%\n" << endl;
					float pv = active_h[i].get_property_value() * 0.75;
					active_h[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_h[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 5){
		
			cout << "The stock market has crashed, all property values have decreased by 30%\n" << endl;
			for(int i=0; i<num_h_owned; i++){
				float pv = active_h[i].get_property_value() * 0.3;
				active_h[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_h[i].get_property_value() << endl;
			}
		}
		else if(num == 6){
			cout << "Gentrification, all property values have increased by 20%" << endl;
			for(int i=0; i<num_h_owned; i++){
				float pv = active_h[i].get_property_value() * 1.2;
				active_h[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_h[i].get_property_value() << endl;
			}
		}
}

/****************************************************************************************************************************************************************************************
** Function: random_event_a
** Description: This function will simulate a random event for apartments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::random_event_a() {
	int num = rand() % 6 + 1;
	//for(int i=0; i<num_a_owned; i++){
		if(num == 1){
			for(int i=0; i<num_a_owned; i++){
				if(active_a[i].get_location() == "SE"){
					cout << "A Hurricane occurred, all property values located in the SE are decreased by 50%\n" << endl;
					float pv = active_a[i].get_property_value() * 0.5;
					active_a[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_a[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 2){
			for(int i=0; i<num_a_owned; i++){
				if(active_a[i].get_location() == "Midwest"){
					cout << "A torando occurred, all property values located in the Midwest have decreased by 30%\n" << endl;
					float pv = active_a[i].get_property_value() * 0.7;
					active_a[i].set_property_value(pv);
					cout << "New Property Valie: \n" << active_a[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 3){
			for(int i=0; i<num_a_owned; i++){
				if(active_a[i].get_location() == "NW"){
					cout << "An earthquake occurred, all property values in the NW have decreased by 90%\n" << endl;
					float pv = active_a[i].get_property_value() * 0.1;
					active_a[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_a[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 4){
			for(int i=0; i<num_a_owned; i++){
				if(active_a[i].get_location() == "SW"){
					cout << "A wildfire occurred, all property values in the SW have decreased by 25%\n" << endl;
					float pv = active_a[i].get_property_value() * 0.75;
					active_a[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_a[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 5){
			cout << "The stock market has crashed, all property values have decreased by 30%\n" << endl;
			for(int i=0; i<num_a_owned; i++){
				float pv = active_a[i].get_property_value() * 0.3;
				active_a[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_a[i].get_property_value() << endl;
			}
		}
		else if(num == 6){
			cout << "Gentrification, all property values have increased by 20%\n" << endl;
			for(int i=0; i<num_a_owned; i++){
				float pv = active_a[i].get_property_value() * 1.2;
				active_b[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_a[i].get_property_value() << endl;
			}
		}
}	

/****************************************************************************************************************************************************************************************
** Function: random_event_b
** Description: This function will simulate a random event for businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::random_event_b() {
	int num = rand() % 6 + 1;	
		if(num == 1){
			for(int i=0; i<num_b_owned; i++){
				if(active_b[i].get_location() == "SE"){
					cout << "A Hurricane occurred, all property values located in the SE are decreased by 50%\n" << endl;
					float pv = active_b[i].get_property_value() * 0.5;
					active_b[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_b[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 2){
			for(int i=0; i<num_b_owned; i++){
				if(active_b[i].get_location() == "Midwest"){
					cout << "A torando occurred, all property values located in the Midwest have decreased by 30%\n" << endl;
					float pv = active_b[i].get_property_value() * 0.7;
					active_b[i].set_property_value(pv);
					cout << "New Property Valie: \n" << active_b[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 3){
			for(int i=0; i<num_b_owned; i++){
				if(active_b[i].get_location() == "NW"){
					cout << "An earthquake occurred, all property values in the NW have decreased by 90%\n" << endl;
					float pv = active_b[i].get_property_value() * 0.1;
					active_b[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_b[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 4){
			for(int i=0; i<num_b_owned; i++){
				if(active_b[i].get_location() == "SW"){
					cout << "A wildfire occurred, all property values in the SW have decreased by 25%\n" << endl;
					float pv = active_b[i].get_property_value() * 0.75;
					active_b[i].set_property_value(pv);
					cout << "New Property Value: \n" << active_b[i].get_property_value() << endl;
				}
			}
		}
		else if(num == 5){
			cout << "The stock market has crashed, all property values have decreased by 30%\n" << endl;
			for(int i=0; i<num_b_owned; i++){
				float pv = active_b[i].get_property_value() * 0.3;
				active_b[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_b[i].get_property_value() << endl;
			}
		}
		else if(num == 6){
			cout << "Gentrification, all property values have increased by 20%\n" << endl;
			for(int i=0; i<num_b_owned; i++){
				float pv = active_b[i].get_property_value() * 1.2;
				active_b[i].set_property_value(pv);
				cout << "New Property Value: \n" << active_b[i].get_property_value() << endl;
			}
		}
}
/****************************************************************************************************************************************************************************************
** Function: change_rent
** Description: This function will allow the user to change the rent
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::change_rent() {
	if(num_h_owned != 0)
		change_rent_h();
	if(num_a_owned != 0)
		change_rent_a();
	if(num_b_owned != 0)
		change_rent_b();
}

/****************************************************************************************************************************************************************************************
** Function: change_rent_h
** Description: This function will allow the user to change the rent for houses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::change_rent_h() {
	for(int i=0; i<num_h_owned; i++){
		cout << "Current House Rent: " << h_owned[i].get_rent() << endl;
		cout << "Would you like to change the rent for this property?\nEnter 1 for yes\nEnter 2 for no\n" << endl;
		int input;
		cin >> input;
		if(input == 1){
			cout << "What would you like to change the rent to?\n" << endl;
			float rent;
			cin >> rent;
			h_owned[i].set_rent(rent);
		}
		else {}
	}
}
		
/****************************************************************************************************************************************************************************************
** Function: change_rent_a
** Description: This function will allow the user to change the rent for the apartments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::change_rent_a() {
	for(int i=0; i<num_a_owned; i++){
		cout << "Current Apartment Complex Rent: " << a_owned[i].get_rent() << endl;
		cout << "Would you like to change the rent for this property?\nEnter 1 for yes\nEnter 2 for no\n" << endl;
		int input;
		cin >> input;
		if(input == 1){
			cout << "What would you like to change the rent to?\n" << endl;
			float rent;
			cin >> rent;
			a_owned[i].set_rent(rent);
		}
		else {}
	}
}
		
/****************************************************************************************************************************************************************************************
** Function: change_rent_b
** Description: This function will allow the user to change the rent for businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::change_rent_b() {
	for(int i=0; i<num_b_owned; i++){
		cout << "Current Business Complex Rent: " << b_owned[i].get_rent() << endl;
		cout << "Would you like to change the rent for this property?\nEnter 1 for yes\nEnter 2 for no\n" << endl;
		int input;
		cin >> input;
		if(input == 1){
			cout << "What would you like to change the rent to?\n" << endl;
			float rent;
			cin >> rent;
			b_owned[i].set_rent(rent);
		}
		else {}
	}
}
		
/****************************************************************************************************************************************************************************************
** Function: get_tax
** Description: This function will collect property tax
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::get_tax(){
	get_tax_h();
	get_tax_a();
	get_tax_b();
	cout << "Bank After Paying Property Tax: \n" << get_bank() << endl;
}

/****************************************************************************************************************************************************************************************
** Function: get_tax_h
** Description: This function will collect property tax for houses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::get_tax_h(){
	for(int i=0; i<num_h_owned; i++){
		bank -= h_owned[i].get_property_tax();
	}
}

/****************************************************************************************************************************************************************************************
** Function: get_tax_a
** Description: This function will collect property tax for apartments
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::get_tax_a(){
	for(int i=0; i<num_a_owned; i++){
		bank -= a_owned[i].get_property_tax();
	}
}

/****************************************************************************************************************************************************************************************
** Function: get_tax_b
** Description: This function will collect property tax for businesses
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::get_tax_b(){
	for(int i=0; i<num_b_owned; i++){
		bank -= b_owned[i].get_property_tax();
	}
}

/****************************************************************************************************************************************************************************************
** Function: take_turn
** Description: This function will simulate each turn of the game
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::take_turn(int num) {
	if(get_bank() < 0 || get_bank() > 1000000){
		if(get_bank() < 0){
			cout << "You your bank account went negative, you lose" << endl;
		}
		else if(get_bank() > 1000000){
			cout << "Your bank account went over 1000000, you win" << endl;
		}
		return;
	}
	cout << "Turn Number: " << num << endl;
	collect_mortgage();
	collect_rent();
	random_event();
	change_rent();
	sell_property();
	if(num %12 == 0){
		get_tax();
	}
	cout << "Number of Properties Owned: \n" << num_h_owned + num_a_owned + num_b_owned << endl;
	cout << "Would you like to buy another property?\nEnter 1 for yes\nEnter 2 for no\n" << endl;
	int input;
	cin >> input;
	if(input == 1){
		buy_property();
		take_turn(num+1);


	}
	else{
		take_turn(num+1);
	}
}

/****************************************************************************************************************************************************************************************
** Function: sell_house
** Description: This function will allow the user to sell a house
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::sell_property() {
	if(num_h_owned != 0)
		sell_house();
	if(num_a_owned != 0)
		sell_apartment();
	if(num_b_owned != 0)
		sell_business();
}

/****************************************************************************************************************************************************************************************
** Function: sell_house
** Description: This function will allow the user to sell a house
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::sell_house() {
	for(int i=0; i<num_h_owned; i++){
		cout << "Would you like to sell House " << i+1 << "?\nTo sell, enter 1, to keep, enter 2" << endl;
		int input; 
		cin >> input;
		if(input == 1){
			cout << "What is your asking price?" << endl;
			float price;
			cin >> price;
			int ran = rand() % 3 + 1;
			switch(ran){
				case 1: cout << "You got your asking price" << endl;
				bank += price;
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 2: cout << "You got the current property value" << endl;
				bank += active_h[i].get_property_value();
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 3: cout << "You got 90% of the property value" << endl;
				bank += active_h[i].get_property_value() * 0.9;
				cout << "Bank Account: " << get_bank() << endl;
				break;
			}
			num_h_owned -= 1;
		}
		else{}
	}
}

/****************************************************************************************************************************************************************************************
** Function: sell_apartment()
** Description: This function will allow the user to sell an apartment
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::sell_apartment(){
	for(int i=0; i<num_a_owned; i++){
		cout << "Would you like to sell Apartment " << i+1 << "?\nTo sell, enter 1, to keep, enter 2" << endl;
		int input; 
		cin >> input;
		if(input == 1){
			cout << "What is your asking price?" << endl;
			float price;
			cin >> price;
			int ran = rand() % 3 + 1;
			switch(ran){
				case 1: cout << "You got your asking price" << endl;
				bank += price;
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 2: cout << "You got the current property value" << endl;
				bank += active_a[i].get_property_value();
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 3: cout << "You got 90% of the property value" << endl;
				bank += active_a[i].get_property_value() * 0.9;
				cout << "Bank Account: " << get_bank() << endl;
				break;
			}
			num_a_owned -= 1;
		}
		else{}
	}
}

/****************************************************************************************************************************************************************************************
** Function: sell_business
** Description: This function will allow the user to sell an apartment
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::sell_business(){
	for(int i=0; i<num_b_owned; i++){
		cout << "Would you like to sell Business " << i+1 << "?\nTo sell, enter 1, to keep, enter 2" << endl;
		int input; 
		cin >> input;
		if(input == 1){
			cout << "What is your asking price?" << endl;
			float price;
			cin >> price;
			int ran = rand() % 3 + 1;
			switch(ran){
				case 1: cout << "You got your asking price" << endl;
				bank += price;
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 2: cout << "You got the current property value" << endl;
				bank += active_b[i].get_property_value();
				cout << "Bank Account: " << get_bank() << endl;
				break;
				case 3: cout << "You got 90% of the property value" << endl;
				bank += active_b[i].get_property_value() * 0.9;
				cout << "Bank Account: " << get_bank() << endl;
				break;
			}
			num_b_owned -= 1;
		}
		else{}
	}
}

/****************************************************************************************************************************************************************************************
** Function: void run_game
** Description: This function will run the game
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::run_game() {
	Game g;
	cout << "Welcome to Real Estate Tycoon" << endl;
	cout << "Your bank account balance is: " << "$" << get_bank() << endl;
	cout << "The number of properties you own is: " << get_num_h_owned() + get_num_a_owned() + get_num_b_owned() << endl;
	cout << "Would you like to buy a property?\nEnter 1 for yes. Enter 2 for no" << endl;
	int input;
	cin >> input;
	if(input == 1){
			buy_property();
			take_turn(1);
	}
	else{
		run_game();
	}
}
	
