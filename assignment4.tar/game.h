#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <vector>
#include <string>
#include "insect.h"
#include "bee.h"
#include "ant.h"
#include "ant_types.h"
#include "game_loc.h"

using namespace std;

class Game {
	public:
		Game();
		~Game();
		vector<Game_Loc> board;
		int food_bank;
		void print_board();
		void game_board();
		void game_turn();
		int num_ants;
		int num_bees;
		Insect *i;
		void harvest();
		void generate_bee();
		void generate_ant();
		void move_bee();
		void bee_attack();
		bool run_game();
		void print_insects();

};

#endif
