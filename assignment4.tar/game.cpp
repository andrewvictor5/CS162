#include "game.h"

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: Game
** Description: Constructor
** Parameters: N/A
** Input: N/A
** Output: Initialized Class
****************************************************************************************************************************************************************************************/

Game::Game() {
	food_bank = 50;
	num_ants = 0;
	num_bees = 0;
	int i;
	for (i=0; i<10; i++) {
		Game_Loc g;
		board.push_back(g);
	}
}

/****************************************************************************************************************************************************************************************
** Function: Game
** Description: Destructor
** Parameters: N/A
** Input: N/A
** Output: Frees Dynamic memory
****************************************************************************************************************************************************************************************/

Game::~Game() {
	board.clear();
}

/****************************************************************************************************************************************************************************************
** Function: print_board
** Description: This function will display the board for the game
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::print_board(){
	for(int i=0; i<10; i++){
		cout << "|  " << i << "  "; 
	}
	cout << "|" << endl << endl;
}

/****************************************************************************************************************************************************************************************
** Function: Game_Board
** Description: This function will generate the board for the game
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

/*void Game::game_board(){
	board = Game_Loc[10];
}*/

/****************************************************************************************************************************************************************************************
** Function: game_turn
** Description: This function will simulate each turn of the game
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::game_turn(){
	print_board();
	cout << "Food Bank: " << food_bank << endl << endl;
	generate_bee();
	generate_ant();
	bee_attack();
}

/****************************************************************************************************************************************************************************************
** Function: generate_bee
** Description: This function will generate a bee
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::generate_bee(){
	Insect in;
	i = &in;
	i->set_damage(1);
	i->set_armor(3);
	i->set_name("Bee");
	board[9].add_insect(i);
	num_bees++;
	cout << "A Bee has been generated on space 9 of the board" << endl << endl;
}

/****************************************************************************************************************************************************************************************
** Function: generate_ant
** Description: This function will 
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

void Game::generate_ant(){
	Insect ins; 
	bool flag = false;
	Harvester a1; Thrower a2; Fire a3; Long_Throw a4; Short_Throw a5; Wall a6; Ninja a7; Bodyguard a8;
	ins = &a1;
	cout << "Please enter the index where you would like to place your ant (1-9)" << endl << endl;
	int input1;
	cin >> input1; 
	cout << "What type of Ant would you like to buy?\n\nTo buy a Harvester Ant, enter 1\nTo buy a Thrower Ant, enter 2\nTo buy a Fire Ant, enter 3\nTo buy a Long Thrower Ant, enter 4\nTo buy a Short Thrower Ant, enter 5\nTo buy a Wall Ant, enter 6\nTo buy a Ninja Ant, enter 7\nTo buy a Bodyguard Ant, enter 8" << endl << endl;
	int input2;
	cin >> input2;
	switch(input2){
		case 1: board[input1].add_insect(i); i = &a1;  cout << "You have generated a Harvester Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a1.get_food_cost();
		break;
		case 2: board[input1].add_insect(i); i = &a2; cout << "You have generated a Thrower Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a2.get_food_cost();
		break;
		case 3: board[input1].add_insect(i); i = &a3; cout << "You have generated a Fire Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a3.get_food_cost();
		break;
		case 4: board[input1].add_insect(i); i = &a4; cout << "You have generated a Long Thrower Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a4.get_food_cost();
		break;
		case 5: board[input1].add_insect(i); i = &a5; cout << "You have generated a Short Thrower Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a5.get_food_cost();
		break;
		case 6: board[input1].add_insect(i); i = &a6; cout << "You have generated a Wall Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a6.get_food_cost();
		break;
		case 7: board[input1].add_insect(i); i = &a7; cout << "You have generated a Ninja Ant at space " << input1 << endl; board[input1].set_occupy(flag); food_bank = food_bank - a7.get_food_cost();
		break;
		case 8: board[input1].add_insect(i); i = &a8; cout << "You have generated a Bodyguard Ant at space " << input1 << endl; food_bank = food_bank - a8.get_food_cost();
		break;
		default: break;
	}
	num_ants++;
}

/****************************************************************************************************************************************************************************************
** Function: bee_attack
** Description: This function will allow the bee to attack
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

void Game::bee_attack() {
	for(int j=0; j<10; j++){
		if(board[j-1].get_occupy() == false) {
			Ant *a;
			a->set_armor(a->get_armor()-1);	
			if(a->get_armor() == 0){
				cout << "The ant died" << endl;
				num_ants --;
			}
		}
		else{
			Insect ins;
			i = &ins;
			board[j].add_insect(i);
		}
	}
}
		
/****************************************************************************************************************************************************************************************
** Function: run_game
** Description: This function will run the game
** Parameters: N/A
** Input: N/A
** Output: bool
****************************************************************************************************************************************************************************************/

bool Game::run_game(){
	bool ants, bees = false;
	while(ants = false || bees == false)
		game_turn();
	if(num_bees == 0){
		cout << "There are no more bees, ants win" << endl;
		return true;
	}
	else if(board[0].insect1->get_name() == "Bee"){
		cout << "The Bees reached the Queen Ant, bees win" << endl;
		return true;
	}
	
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

void Game::print_insects(){
	cout << "Insects on the Board: " << endl;
	for(int i=0; i<10; i++){
		cout << board[i].insect1->get_name() << endl;
	}
}
