#include <iostream>
#include <vector>
#include <string>
#include "insect.h"
#include "game.h"

using namespace std;

int main() {
	Game g;
	cout << "Welcome to Ants vs Bees" << endl << endl <<"The Queen Ant is located on Space 0 of the board" << endl << endl << "The Bees will generate on Space 9 of the board" << endl << endl << "Good luck!" << endl << endl;
	g.run_game();
	return 0;
}
