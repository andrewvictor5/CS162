#ifndef ANT_H
#define ANT_H
#include "insect.h"

using namespace std;

class Ant:public Insect{

	protected:
		int food_cost;
		string type;
		bool can_occupy;
	public:
		Ant();
		Ant(const Ant &);
		const Ant &operator=(const Ant &);
		~Ant();
		int get_food_cost();
		void set_food_cost(int);
		string get_type() const;
		void set_type(string);
		virtual void attack() = 0;
		int get_num_ants() const;
		void set_num_ants(int);
		int num_ants;
};
#endif

