#ifndef ANT_TYPES_H 
#define ANT_TYPES_H
#include "ant.h"
#include "insect.h"

using namespace std;

class Harvester:public Ant{
	
	public:
		Harvester();
		~Harvester();
		virtual void attack();

};

class Thrower:public Ant{

	public:
		Thrower();
		~Thrower();
		bool valid_attack();
		virtual void attack();

};

class Fire:public Ant{
	
	private:
		bool alive;
	public:
		Fire();
		~Fire();
		bool get_alive();
		void set_alive(bool);
		bool is_alive();
		virtual void attack();

};

class Long_Throw:public Ant{

	private:

	public:
		Long_Throw();
		~Long_Throw();
		bool valid_attack();
		virtual void attack();

};

class Short_Throw:public Ant{

	private:

	public:
		Short_Throw();
		~Short_Throw();
		bool valid_attack();
		virtual void attack();

};

class Wall:public Ant{

	private:

	public:
		Wall();
		~Wall();
		virtual void attack();

};

class Ninja:public Ant{

	private:

	public:
		Ninja();
		~Ninja();
		virtual void attack();

};

class Bodyguard:public Ant{

	private:
		bool ant_val();
	public:
		Bodyguard();
		~Bodyguard();
		bool get_ant();
		void set_ant(bool);
		virtual void attack();
};

	
#endif
