#ifndef INSECT_H
#define INSECT_H
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Insect {

	private:

	protected:
		int damage;
		int armor;
		string name;
		//string type;
		//int food_cost;
	public:
		Insect();
		Insect * operator=(const Insect * copy);
		int get_armor();
		void set_armor(int);
		string get_name() const;
		void set_name(string);
		int get_damage() const;
		void set_damage(int);
		string get_type() const;
		void set_type(string);
		int get_food_cost() const;
		void set_food_cost(int);
		Insect(const Insect &);
		//const Insect &operator = (const Insect &);
		~Insect();

};
#endif
