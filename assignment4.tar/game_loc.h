#ifndef GAME_LOC_H
#define GAME_LOC_H
#include "insect.h"
#include <iostream>
#include <vector>

using namespace std;

class Game_Loc{
	private:
		bool can_occupy;
		int contains_insect;
		bool contains_queen;
		bool can_attack;
		
	public:
		Game_Loc();
		~Game_Loc();
		Game_Loc* operator=(const Game_Loc *copy);
		bool get_occupy();
		Insect *insect1;
		Insect *insect2;
		Insect *insect3;
		void set_occupy(bool);
		int get_insect();
		//void set_insect(int);
		bool get_queen();
		void set_queen(bool);
		bool get_attack();
		void set_attack(bool);
		void add_insect(Insect *);
		void remove_insect(Insect *);
};

#endif
