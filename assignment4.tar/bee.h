#ifndef BEE_H
#define BEE_H
#include "insect.h"

using namespace std;

class Bee:public Insect{

	public:
		Bee();
		Bee(const Bee &);
		const Bee &operator =(const Bee &);
		~Bee();
		int get_attack() const;
		void set_attack(int);
		bool valid_move();
		void move_bee();
		void bee_attack();
};

#endif 
