#ifndef STRUCTS_H
#define STRUCTS_H
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct employee{

	string id;
	string first_name;
	string last_name;
	string password;

};

struct hours{

	string day;
	string open_hour;
	string close_hour;

};

#endif 

int get_num_employees();
void set_employees(int);
void get_store_information();
void set_store_information();
