#ifndef PIZZA_H
#define PIZZA_H
#include <iostream>
#include <string>

using namespace std;

class Pizza{
	private:
		
		string name;
		int small_cost;
		int medium_cost;
		int large_cost;
		int num_ingredients;
		string* ingredients;

	public:

		Pizza();
		Pizza(string, int, int, int, int, string*);
		void set_name(string name);
		string get_name() const;
		void set_small_cost(int);
		int get_small_cost() const;
		void set_medium_cost(int);
		int get_medium_cost() const;
		void set_large_cost(int);
		int get_large_cost() const;
		void set_num_ingredients(int);
		int get_num_ingredients() const;
		string* get_ingredients();
		void set_ingredients(string *);
		void set_from_file();
		Pizza(const Pizza&);
		const Pizza& operator=(const Pizza &);
		~Pizza();
};
#endif

