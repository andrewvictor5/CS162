#include <iostream>
#include "structs.h"
#include "pizza.h"
#include "menu.h"
#include "restaurant.h"

using namespace std;

int main() {
	
	Restaurant r;
	r.load_data();
	r.main_menu();
	
	return 0;
}
