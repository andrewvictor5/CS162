#include "restaurant.h"
#include "menu.h"
#include "pizza.h"
#include "structs.h"
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <sstream>

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: get_name
** Description: This will get the name from the file
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/
string Restaurant::get_name() const {return name;}

/****************************************************************************************************************************************************************************************
** Function: set_name
** Description: This function will set the name
** Parameters: N/A
** Input: string
** Output: string
****************************************************************************************************************************************************************************************/

void Restaurant::set_name(string s) {name = s;}

/****************************************************************************************************************************************************************************************
** Function: get_phone
** Description: This function will get the phone number from the file
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

string Restaurant::get_phone() const {return phone;}

/****************************************************************************************************************************************************************************************
** Function: set_phone
** Description: This function will set the phone number
** Parameters: string
** Input: string
** Output: string
****************************************************************************************************************************************************************************************/

void Restaurant::set_phone(string s) {phone = s;}

/****************************************************************************************************************************************************************************************
** Function: get_address
** Description: This function will get the address from the file
** Parameters: N/A
** Input: N/A
** Output: string
****************************************************************************************************************************************************************************************/

string Restaurant::get_address() const {return address;}

/****************************************************************************************************************************************************************************************
** Function: set_address
** Description: This function will set the address
** Parameters: string
** Input: string
** Output: string
****************************************************************************************************************************************************************************************/

void Restaurant::set_address(string s) {address = s;}

/****************************************************************************************************************************************************************************************
** Function: Restaurant
** Description: Default Constructor for Restaurant Class
** Parameters: N/A
** Input: Called when the object is created
** Output: Class with initialized values
****************************************************************************************************************************************************************************************/

Restaurant::Restaurant() {
	employees = NULL;
	week = NULL;
	name = " ";
	phone = " ";
	address = " ";	
}

/****************************************************************************************************************************************************************************************
** Function: Restaurant Constructor
** Description: Constructor
** Parameters: string, string, string
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

Restaurant::Restaurant(employee *employees, hours *week, string n, string p, string a){
	employees = NULL;
	week = NULL;
	set_name(n);
	set_phone(p);
	set_address(a);
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

Menu Restaurant::get_menu() {return menu;}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

void Restaurant::set_menu(Menu m) {menu = m;}

/****************************************************************************************************************************************************************************************
** Function: get_pizzas_from_file
** Description: This function will get all of the information for the pizzas from the file
** Parameters: Int
** Input: N/A
** Output: Populated file
****************************************************************************************************************************************************************************************/
void Restaurant::get_pizzas_from_file(){
	fstream file;
	file.open("menu.txt");
	if(file.fail()){
		cout << "Invalid file\nPlease use menu.txt" << endl;
	}
	if(file.is_open()){
	string name;
	Menu menu;
	int pizza_count = menu.get_num_pizzas();
	//cout << "NUM PIZZAS: " << pizza_count << endl;
	menu.set_pizzas(pizza_count);
	Pizza *p = new Pizza[pizza_count];
	int small_cost = 0, medium_cost = 0, large_cost = 0, num_ingredients = 0;
	for(int i=0; i<pizza_count; i++){
		file >> name;
		file >> small_cost;
		file >> medium_cost;
		file >> large_cost;
		file >> num_ingredients;
		string *ingredients = new string[num_ingredients];
		for(int j=0; j<num_ingredients; j++){
			file >> ingredients[j];
		}
		p[i] = Pizza(name, small_cost, medium_cost, large_cost, num_ingredients, ingredients);
	}
	for(int i=0; i<pizza_count; i++){
		cout << p[i].get_name() << endl;
		cout << p[i].get_small_cost() << endl;
	}
	}
	file.close();
}

/****************************************************************************************************************************************************************************************
** Function: main_menu
** Description: This function will display the main menu for the pizza website
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/
void Restaurant::main_menu() {	
cout << "Welcome to the Pizza Shop" << endl;
cout << "Are you an Employee (E), Customer (C), or would you like to quit (Q)" << endl;
char input;
cin >> input;
char input_upper = toupper(input);

while(input_upper != 'E' && input_upper != 'C' && input_upper != 'Q'){
	cout << "Invalid Input\nPlease try again" << endl;
	cin >> input;
	input_upper = toupper(input);
}

	if(input_upper == 'E'){
		//cout << "Employee Worked" << endl;
		employee_menu();
	}
	if(input_upper == 'C'){
		//cout << "Customer Worked" << endl;
		customer_menu();
	}
	if(input_upper == 'Q'){
		//cout << "Quit Worked" << endl;
		exit(0);
	}
}
/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::customer_menu() {
cout << "Customer Mode\nWhat would you like to do?\n1. View Menu\n2. Search By Cost\n3. Search By Ingredients\n4. Place Order\n5. View Hours\n6. View Address\n7. View Phone\n8. Log Out" << endl;
char input;
cin >> input;
char input_upper = toupper(input);
while(input_upper < '0' || input_upper > '9'){
	cout << "Invalid Input\nPlease try again" << endl;
	cin >> input;
	input_upper = toupper(input);
}	
	if(input_upper == '1'){
		view_menu();
		customer_menu();
	}
	if(input_upper == '2'){
		cout << "Search By Cost Worked" << endl;
	}
	if(input_upper == '3'){
		cout << "Search By Ingredients Worked" << endl;
	}
	if(input_upper == '4'){
		add_order();
	}
	if(input_upper == '5'){
		view_hours();
		customer_menu();
	}
	if(input_upper == '6'){
		view_address();
		customer_menu();
	}
	if(input_upper == '7'){
		view_phone();
		customer_menu();
	}
	if(input_upper == '8'){
		cout << "Log Out" << endl;
		main_menu();
	}
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::employee_menu() {
cout << "Employee Menu\nWhat would you like to do?\n1. Change Hours\n2. View Orders\n3. Remove Order\n4. Add Item to Menu\n5. Remove Item from Menu\n6. View Menu\n7. View Hours\n8. View Address\n9. View Phone\n0. Log Out" << endl;
char input;
cin >> input;
char input_upper = toupper(input);
while(input_upper < '0' || input_upper > '9'){
	cout << "Invalid Input\nPlease try again" << endl;
	cin >> input;
	input_upper = toupper(input);
}
	if(input == '1'){
		cout << "Change Hours Worked" << endl;
	}
	if(input == '2'){
		view_order();
		employee_menu();
	}
	if(input == '3'){
		remove_order();
		employee_menu();
	}
	if(input == '4'){
		cout << "Add Item to Menu" << endl;
	}
	if(input == '5'){
		cout << "Remove Item From Menu" << endl;
	}
	if(input == '6'){
		view_menu();
		employee_menu();
	}
	if(input == '7'){
		view_hours();
		employee_menu();
	}
	if(input == '8'){
		view_address();
		employee_menu();
	}
	if(input == '9'){
		view_phone();
		employee_menu();
	}
	if(input == '0'){
		cout << "Log Out" << endl;
		main_menu();
	}
}
/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::load_data() {
	int num_employees = 0;
	get_pizzas_from_file();
	set_employees(num_employees);
	get_restaurant_info();
}

/****************************************************************************************************************************************************************************************
** Function: get_restaurant_info
** Description: This function will read in the 
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::get_restaurant_info(){
	fstream file;
	int days_open = 0;
	file.open("restaurant_info.txt");
	if(file.fail()){
		cout << "Invalid File\nPlease try again" << endl;
	}
	if(file.is_open()){
		string line1;
		getline(file, line1);
		set_name(line1);
		//cout << line1 << endl;
		string line2;
		getline(file, line2);
		set_phone(line2);
		//cout << line2 << endl;
		string line3;
		getline(file, line3);
		set_address(line3);
		//cout << line3 << endl;
		string line4;
		getline(file, line4);
		file >> days_open;
		//cout << days_open << endl;
	file.close();	
	}
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

bool Restaurant::check_id(){
}

/****************************************************************************************************************************************************************************************
** Function: login
** Description: This function will allow the user to log in if they are an employee
** Parameters: string, string
** Input: N/A
** Output: bool
****************************************************************************************************************************************************************************************/

/*bool Restaurant::login(string id, string password){
	bool check;
	cout << "Please enter your employee ID" << endl;
	cin >> id;
	if(id == true){
		cout << "Please enter your password" << endl;
		cin >> password;
		if(password == true){
			cout << "Login Successful" << endl;
			employee_menu();
		}
		else{
			while(password == false){
				cout << "Invalid Password, please try again" << endl;
				cin >> password;
			}
		}
	}
	else{
		while(id == false){
			cout << "Invalid ID, please try again" << endl;
			cin >> id;
		}
	}
}*/

/****************************************************************************************************************************************************************************************
** Function: add_order
** Description: This will allow a customer to order a pizza
** Parameters: N/A
** Input: N/A
** Output: File
****************************************************************************************************************************************************************************************/
void Restaurant::add_order(){
	fstream file;
	file.open("order.txt");
	if(file.fail()){
		cout << "Invalid file\nPlease use order.txt" << endl;
	}
	if(file.is_open()){
		file << "Order 1" << endl;
		string name;
		cout << "Please enter the name for the order" << endl;
		cin >> name; cin.clear(); cin.ignore();	
		file << name << endl;
		string cc;
		cout << "Please enter your credit card number" << endl;
		cin >> cc; cin.clear(); cin.ignore();
		file << cc << endl;
		cout << "Please enter the delivery address" << endl;
		string ad;
		cin >> ad; cin.clear(); cin.ignore();
		file << ad << endl;
		cout << "Please enter the phone number for the order" << endl;
		string p;
		cin >> p; cin.clear(); cin.ignore();
		file << p << endl;
		cout << "Please enter the name of the pizza you wish to order" << endl;
		string pi;
		cin >> pi; cin.clear(); cin.ignore();
		file << pi << endl;
		cout << "Please enter the size of the pizza that you wish to order" << endl;
		string si;
		cin >> si; cin.clear(); cin.ignore();
		file << si << endl;
		cout << "Please enter the number of pizzas you wish to order" << endl;
		string num;
		cin >> num; cin.clear(); cin.ignore();
		file << num << endl;
		cout << "Would you like to add another pizza to your order?\nIf yes, please enter 1, if no, please enter 2" << endl;
		int input;
		cin >> input;
		if(input == 1){
			cout << "Please enter the pizza you wish to order" << endl;
			string pi2;
			cin >> pi2; cin.clear(); cin.ignore();
			file << pi2 << endl;
			cout << "Please enter the size" << endl;
			string si2;
			cin >> si2; cin.clear(); cin.ignore();
			file << si2 << endl;
			cout << "Please enter the quantity" << endl;
			string num2;
			cin >> num2; cin.clear(); cin.ignore();
			file << num2 << endl;
			customer_menu();
		}
		else{
			customer_menu();
		}
	}
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::remove_order() {
	cout << "Would you like to remove the current order?\nTo remove, enter 1, to save, enter 2" << endl;
	int input;
	cin >> input;
	if(input == 1){
		fstream file;
		file.open("order.txt", ios::out | ios::trunc);
	}
	else{
		employee_menu();
	}
}

/****************************************************************************************************************************************************************************************
** Function: Restaurant 
** Description: Copy Constructor
** Parameters: N/A
** Input: N/A
** Output: Copy of the class
****************************************************************************************************************************************************************************************/
Restaurant::Restaurant(const Restaurant & copy){
	menu = copy.menu;
	employees = copy.employees;
	week = copy.week;
	name = copy.name;
	phone = copy.phone;
	address = copy.address;
}

/****************************************************************************************************************************************************************************************
** Function: get_num_employees
** Description: This function will get the number of employees from the file
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/
int Restaurant::get_num_employees() {
	fstream file;
	file.open("employee.txt");
	if(file.fail())
		cout << "Invalid file" << endl;
	if(file.is_open()){
		int num_employees = 0;
		//cout << "Initial Number of Employees: " << num_employees << endl;
		string word;
		while(getline(file, word)){
			++num_employees;
		}
		num_employees = num_employees -1;
		//cout << "Final Num Employees: " << num_employees << endl;
		file.close();
		return num_employees;
	}
}

/****************************************************************************************************************************************************************************************
** Function: set_employees
** Description: This function will set the employee information
** Parameters: int
** Input: int, file
** Output: struct
****************************************************************************************************************************************************************************************/
void Restaurant::set_employees(int num_employees){
	num_employees = get_num_employees();
	//cout << "NUM EMPLOYEES: " << num_employees << endl;
	fstream file;
	file.open("employee.txt");
	if(file.fail()){
		cout << "Invalid File\nPlease use employee.txt" << endl;
	}
	employee *employees = new employee[num_employees];
	for(int i=0; i<num_employees; i++){
		file >> employees[i].id;
		file >> employees[i].first_name;
		file >> employees[i].last_name;
		file >> employees[i].password;
	}
	file.close();
	/*for(int i=0; i<num_employees; i++){
		cout << employees[i].id << endl;
		cout << employees[i].first_name << endl;
		cout << employees[i].last_name << endl;
		cout << employees[i].password << endl;
	}*/
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::view_order(){
	fstream file;
	file.open("order.txt");
	string s;
	if(file.fail()){
		cout << "Invalid file, please try again" << endl;
	}
	while(getline(file, s)){
		 //file >> s;
		 cout << s << endl;
	}
	file.close();
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::view_menu(){
	fstream file;
	string line;
	file.open("menu.txt");
	string name, small, medium, large, num_ingredients;
	if(file.fail()){
		cout << "Invalid File" << endl;
	}
	if(file.is_open()){
		while(!file.eof()){
			getline(file, line);
			cout << line << endl;
		}
	}
	file.close();
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::view_address(){
	fstream file;
	file.open("restaurant_info.txt");
	string line1, line2, line3;
	if(file.fail()){
		cout << "Invalid File" << endl;
	}
	if(file.is_open()){
		getline(file, line1);
		getline(file, line2);
		getline(file, line3);
		cout << line3 << endl;
	}
	file.close();
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::view_phone(){
	fstream file;
	file.open("restaurant_info.txt");
	string line1, line2;
	if(file.fail()){
		cout << "Invalid File" << endl;
	}
	if(file.is_open()){
		getline(file, line1);
		getline(file, line2);
		cout << line2 << endl;
	}
	file.close();
}

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/
void Restaurant::view_hours(){
	fstream file;
	file.open("restaurant_info.txt");
	string line1, line2, line3, line4, line5;
	if(file.fail()){
		cout << "Invalid File" << endl;
	}
	if(file.is_open()){
		getline(file, line1);
		getline(file, line2);
		getline(file, line3);
		getline(file, line4);
		while(!file.eof()){
			getline(file, line5);
			cout << line5 << endl;
		}
	}
	file.close();
}
/****************************************************************************************************************************************************************************************
** Function: Restaurant
** Description: Assignment Operator Overload
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/
const Restaurant &Restaurant::operator=(const Restaurant &copy){
	menu = copy.menu;
	int num = get_num_employees();
	if(employees != NULL){
		delete [] employees;
	}
	else{
		employees = new employee[num];
		for(int i=0; i<num; i++){
			employees[i] = copy.employees[i];
		}
	}
	week = copy.week;
	name = copy.name;
	phone = copy.phone;
	address = copy.address;
}
/****************************************************************************************************************************************************************************************
** Function: Restaurant 
** Description: Destructor
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/

Restaurant::~Restaurant() {
	delete [] employees;
	delete [] week;
}
