#include "structs.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

/****************************************************************************************************************************************************************************************
** Function:
** Description:
** Parameters:
** Input:
** Output:
****************************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************************
** Function: get_num_employees
** Description: This function will get the number of employees from the file
** Parameters: N/A
** Input: N/A
** Output: N/A
****************************************************************************************************************************************************************************************/
int get_num_employees() {
	fstream file;
	file.open("employee.txt");
	if(file.fail())
		cout << "Invalid file" << endl;
	if(file.is_open()){
		int num_employees = 0;
		//cout << "Initial Number of Employees: " << num_employees << endl;
		string word;
		while(getline(file, word)){
			++num_employees;
		}
		num_employees = num_employees -1;
		//cout << "Final Num Employees: " << num_employees << endl;
		file.close();
		return num_employees;
	}
}

/****************************************************************************************************************************************************************************************
** Function: set_employees
** Description: This function will set the employee information
** Parameters: int
** Input: int, file
** Output: struct
****************************************************************************************************************************************************************************************/
void set_employees(int num_employees){
	num_employees = get_num_employees();
	cout << "NUM EMPLOYEES: " << num_employees << endl;
	fstream file;
	file.open("employee.txt");
	if(file.fail()){
		cout << "Invalid File\nPlease use employee.txt" << endl;
	}
	employee *employees = new employee[num_employees];
	for(int i=0; i<num_employees; i++){
		file >> employees[i].id;
		file >> employees[i].first_name;
		file >> employees[i].last_name;
		file >> employees[i].password;
	}
	file.close();
	for(int i=0; i<num_employees; i++){
		cout << employees[i].id << endl;
		cout << employees[i].first_name << endl;
		cout << employees[i].last_name << endl;
		cout << employees[i].password << endl;
	}
}
