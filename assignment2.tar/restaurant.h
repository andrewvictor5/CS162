#ifndef RESTAURANT_H
#define RESTAURANT_H
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include "structs.h"
#include "menu.h"
#include "pizza.h"

using namespace std;

class Restaurant{

	private:

		Menu menu;
		employee* employees;
		hours* week;
		string name;
		string phone;
		string address;

	public:
	
		Restaurant();
		Restaurant(employee*, hours*, string, string, string);
		int get_num_pizzas();
		void get_pizzas_from_file();
		void print_pizzas(const Pizza &);
		Menu get_menu();
		void set_menu(Menu m);	
		void load_data();
		void main_menu();
		bool check_id();
		bool check_password();
		void add_order();
		void customer_menu();
		void employee_menu();
		int get_num_employees();
		void set_employees(int);
		void get_restaurant_info();
		string get_name() const;
		void set_name(string);
		string get_phone() const;
		void set_phone(string);
		string get_address() const;
		void set_address(string);
		bool login(string id, string password);
		void view_hours();
		void view_menu();
		void view_address();
		void view_phone();
		void search_menu_by_price ();
		void search_by_ingredients();
		void change_hours();
		void remove_from_menu();
		void view_order();
		void remove_order();
		Restaurant(const Restaurant &);
		const Restaurant& operator=(const Restaurant &);
		~Restaurant();

};
#endif
